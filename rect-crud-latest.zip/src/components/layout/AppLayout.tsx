import { useEffect, useState } from 'react'
import { Alert, Avatar, Card, Empty, Layout, Menu, Typography } from 'antd'
import {
  AppstoreOutlined,
  BarChartOutlined,
  SettingOutlined,
  ShoppingCartOutlined,
  TagOutlined,
} from '@ant-design/icons'
import { api, type Product } from '../../api/products'
import { formatPrice } from '../../utils/format'
import Dashboard from '../../pages/Dashboard'
import Products from '../../pages/Products'
import ZnsConfigs from '../../pages/zns/ZnsConfigs'
import ZnsHistory from '../../pages/zns/ZnsHistory'

const layoutStyles = `
  .layout {
    min-height: 100svh;
  }

  .sidebar {
    position: sticky;
    top: 0;
    height: 100svh;
    border-right: 1px solid #f0f0f0;
    display: flex;
    flex-direction: column;
    overflow: hidden;
  }

  .sidebar-brand {
    display: flex;
    align-items: center;
    gap: 10px;
    padding: 18px 20px;
  }

  .brand-badge {
    width: 34px;
    height: 34px;
    display: grid;
    place-items: center;
    border-radius: 9px;
    background: #1677ff;
    color: #fff;
    font-weight: 700;
    flex-shrink: 0;
  }

  .brand-name {
    font-size: 16px;
    font-weight: 650;
    color: rgba(0, 0, 0, 0.88);
  }

  .sidebar-menu {
    flex: 1;
    overflow-y: auto;
    border-inline-end: none !important;
  }

  .sidebar-footer {
    display: flex;
    align-items: center;
    gap: 10px;
    padding: 16px 20px;
    border-top: 1px solid #f0f0f0;
  }

  .user-avatar {
    background: #1677ff !important;
    color: #fff;
    font-weight: 650;
    flex-shrink: 0;
  }

  .user-name {
    font-size: 14px;
    font-weight: 600;
    color: rgba(0, 0, 0, 0.88);
  }

  .user-role {
    font-size: 12px;
    color: rgba(0, 0, 0, 0.45);
  }

  .topbar {
    background: #fff !important;
    padding: 0 24px !important;
    line-height: normal !important;
    display: flex;
    align-items: center;
    justify-content: space-between;
    gap: 16px;
    flex-wrap: wrap;
    border-bottom: 1px solid #f0f0f0;
    height: auto !important;
    min-height: 64px;
    padding-block: 12px !important;
  }

  .search-input {
    width: 240px;
  }

  .content {
    padding: 24px;
    background: #f5f5f5;
  }

  .data-table {
    background: #fff;
  }

  .cell-name {
    font-weight: 600;
  }

  .cell-desc {
    color: rgba(0, 0, 0, 0.45);
    font-size: 13px;
    margin-top: 2px;
    max-width: 300px;
    overflow: hidden;
    text-overflow: ellipsis;
    white-space: nowrap;
  }

  .cell-total {
    color: #1677ff;
    font-weight: 600;
  }

  .cell-date {
    color: rgba(0, 0, 0, 0.45);
    font-size: 13px;
    white-space: nowrap;
  }

  @media (max-width: 768px) {
    .search-input {
      width: 100%;
    }

    .topbar {
      padding: 12px 16px !important;
    }

    .content {
      padding: 16px;
    }
  }
`

const NAV_ITEMS = [
  { key: 'dashboard', icon: <AppstoreOutlined />, label: 'Tổng Ghi chú nhanh' },
  { key: 'products', icon: <ShoppingCartOutlined />, label: 'Sản phẩm' },
  { key: 'categories', icon: <TagOutlined />, label: 'Danh mục' },
  { key: 'orders', icon: <BarChartOutlined />, label: 'Đơn hàng' },
  { key: 'reports', icon: <BarChartOutlined />, label: 'Báo cáo' },
  {
    key: 'settings',
    icon: <SettingOutlined />,
    label: 'Cài đặt',
    children: [
      { key: 'zns', label: 'Cấu hình ZNS' },
      { key: 'zns-history', label: 'Lịch sử gửi ZNS' },
    ],
  },
]

const PAGE_TITLES: Record<string, string> = {
  dashboard: 'Ghi chú nhanh',
  products: 'Sản phẩm',
  zns: 'Cấu hình ZNS',
  'zns-history': 'Lịch sử gửi ZNS',
}

function AppLayout() {
  const [products, setProducts] = useState<Product[]>([])
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState<string | null>(null)
  const [activeKey, setActiveKey] = useState('products')

  useEffect(() => {
    const controller = new AbortController()
    api
      .listProducts(controller.signal)
      .then((data) => {
        setError(null)
        setProducts(data)
      })
      .catch((e) => {
        if (!controller.signal.aborted) {
          setError(e instanceof Error ? e.message : 'Không thể tải sản phẩm')
        }
      })
      .finally(() => setLoading(false))
    return () => controller.abort()
  }, [])

  const totalValue = products.reduce((sum, p) => sum + p.price * p.quantity, 0)

  return (
    <>
      <style>{layoutStyles}</style>
      <Layout className="layout">
        <Layout.Sider className="sidebar" width={240} theme="light">
          <div className="sidebar-brand">
            <span className="brand-badge">P</span>
            <span className="brand-name">Quản lý kho</span>
          </div>
          <Menu
            className="sidebar-menu"
            mode="inline"
            selectedKeys={[activeKey]}
            items={NAV_ITEMS}
            onClick={({ key }) => setActiveKey(key)}
          />
          <div className="sidebar-footer">
            <Avatar size={36} className="user-avatar">
              N
            </Avatar>
            <div>
              <div className="user-name">Người dùng</div>
              <div className="user-role">Quản trị viên</div>
            </div>
          </div>
        </Layout.Sider>

        <Layout>
          <Layout.Header className="topbar">
            <div className="topbar-title">
              <Typography.Title level={4} style={{ margin: 0 }}>
                {PAGE_TITLES[activeKey] ?? NAV_ITEMS.find((i) => i.key === activeKey)?.label ?? ''}
              </Typography.Title>
              <Typography.Text type="secondary">
                {activeKey === 'products'
                  ? `${products.length} sản phẩm · Tổng giá trị ${formatPrice(totalValue)}`
                  : activeKey === 'zns' || activeKey === 'zns-history'
                    ? 'Quản lý thông báo Zalo ZNS'
                    : `${products.length} sản phẩm đang được quản lý`}
              </Typography.Text>
            </div>
          </Layout.Header>

          <Layout.Content className="content">
            {error && (
              <Alert
                type="error"
                showIcon
                closable
                message={error}
                onClose={() => setError(null)}
                style={{ marginBottom: 16 }}
              />
            )}

            {activeKey === 'dashboard' ? (
              <Dashboard products={products} />
            ) : activeKey === 'products' ? (
              <Products products={products} loading={loading} setProducts={setProducts} />
            ) : activeKey === 'zns' ? (
              <ZnsConfigs />
            ) : activeKey === 'zns-history' ? (
              <ZnsHistory />
            ) : (
              <Card style={{ marginTop: 16 }}>
                <Empty description="Trang này đang được xây dựng" />
              </Card>
            )}
          </Layout.Content>
        </Layout>
      </Layout>
    </>
  )
}

export default AppLayout
